Chapter 2 (مروری بر پیشینه پژوهش) — full draft, NOT compiled (build on your side).
==================================================================================
tex/  (drop into thesis/latex/.../sections/)  — each file carries its SOURCE MAP
      (claim -> key) as header comments for verification.

  2-1-reviews.tex        DONE     reviews & bibliometrics (9 keys; jedrzejewski anchor)
  2-2-statistical.tex    DONE     classical/statistical; Eq (ARX) + Eq (ARIMA)
  2-3-classical-ml.tex   DONE     classical ML (ANN/SVM/GP/ANFIS)
  2-4-deep.tex           DONE     deep learning; Eq (generic RNN recurrence)
  2-5-hybrid.tex         DONE     hybrid & attention; Eq (weighted ensemble)
  2-6-xai.tex            THIN*    interpretability / explainable AI
  2-7-applied.tex        DONE     market-specific studies + German cluster
  2-8-longterm.tex       DONE     long-term & probabilistic
  2-9-gap.tex            DONE     research gap & positioning (payoff)

* 2-6 is genuinely thin/partially blocked: trebbien_explainable_2023 has NO
  abstract in references.bib, so only a title-level mention is grounded, and
  lucas_price_2020 is not clearly XAI (it was placed in 2-7 instead). To reach a
  full 2pp and detail SHAP/feature-attribution, PASTE a passage from trebbien_2023.

QA (compile-free, run this side to confirm):
  - 0 invalid \cite keys; every key exists in references.bib (LaTeX keys, not
    Zotero _nodate variants).
  - 0 bare numerals / em-dashes in printed text; all wrapped in \lr{} (math-mode
    digits inside equations are correctly NOT wrapped).
  - All 41 library keys are now cited across ch1 + ch2.

Equations: 5 total (2 in 2-2, 1 in 2-4, 1 in 2-5), all single-line canonical
  forms. NOTE the RTL numbering convention: eq (۲-۱) reads right-to-left as
  "chapter 2, eq 1" — identical to how section numbers render. Verify on compile.

Reminders (unchanged): add SHAP origin paper (Lundberg & Lee 2017) to
  references.bib for Ch3/Ch4; bank real page counts from the official B-Nazanin
  compile (this bundle is not compiled).
