Chapter 1 (مقدمه) — COMPLETE & REVIEWED. All six sections drafted.
==================================================================
Files sorted by type: tex/ and pdf/.

tex/  (drop into thesis/latex/.../sections/)
  1-1-motivation.tex      APPROVED   (انگیزه و اهمیت موضوع, expanded)
  1-2-problem.tex         APPROVED   (بیان مسئله, expanded)
  1-3-questions.tex       DRAFTED*   (سؤالات پژوهش — 4 RQs)
  1-4-contributions.tex   APPROVED   (نوآوری‌ها و دستاوردها, expanded)
  1-5-structure.tex       APPROVED   (ساختار پایان‌نامه)
  1-6-scope.tex           APPROVED   (محدوده و مفروضات, detailed)

pdf/
  ch1-preview.pdf         full chapter, 10 pp (SUBSTITUTE fonts: Nazli for
                          B Nazanin, Liberation Serif for Times New Roman)

* 1-3: RQ1-3 provisional (reconcile vs approved proposal at review of 1-3/4-7;
  proposal wins on wording, answers unaffected). RQ4 firm. RQ5 (OOD) optional,
  not included -> lead count چهار; if adopted it APPENDS as RQ5 (چهار->پنج).
